<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>El juego | Nombre del videojuego</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main class="internal-page">

        <div class="content-container">

            <header class="page-header">
                <h1>El juego</h1>

                <p>
                    Conoce el concepto, las mecánicas y la experiencia
                    que propone el videojuego.
                </p>
            </header>


            <section class="game-description">

                <h2>Niveles</h2>

                <p>
                    Cosmo brinda al jugador diversos mundos que combinan la supervivencia, disparo y plataforma. En ellos se alojan niveles de dos tipos: niveles 3D donde el movimiento es libre (X,Y,Z), y 2.5D donde el movimiento es horizontal y vertical (X,Y) como en juegos arcade tradicionales. 
                </p>

            </section>


            <section class="target-audience">

                <h2>Público objetivo</h2>

                <p>
                    Jugadores casuales y con interés por juegos de terror. El proyecto prioriza la accesibilidad al aprender las mecánicas. El objetivo es no utilizar manuales o textos largos para aprender y empezar a jugar.
                </p>

            </section>


            <section class="mechanics">

                <h2>Mecánicas principales</h2>

                <div class="card-container">

                    <article class="card">
                        <h3>Esencia</h3>
                        <p>
                            El juego utiliza un sistema unificado basado en la “esencia”, la cual funciona como recurso dual que representa tanto la vida como la energía necesaria para ejecutar habilidades (poderes).
                        </p>
                    </article>

                    <article class="card">
                        <h3>Vulnerabilidad</h3>
                        <p>
                            Agotar la esencia provoca que el personaje sea vulnerable, haciendo que cualquier daño recibido provoque un Game Over.
                        </p>
                    </article>

                    <article class="card">
                        <h3>Control y Combate</h3>
                        <p>
                            Sube montañas y plataformas, salta en el aíre. Haz un disparo cargado o defiendete con una barrera temporal.
                        </p>
                    </article>

                </div>

            </section>


            <section class="mockups">

                <h2>Mockups y prototipos</h2>

                <p>
                    Explora algunas imágenes del concepto visual
                    del videojuego.
                </p>

                <div class="carousel">

                    <button
                        type="button"
                        id="previous-button"
                        aria-label="Imagen anterior">
                        &#10094;
                    </button>

                    <figure>
                        <img
                            id="carousel-image"
                            src="img/mockup-01.jpg"
                            alt="Mockup del videojuego">
                    </figure>

                    <button
                        type="button"
                        id="next-button"
                        aria-label="Imagen siguiente">
                        &#10095;
                    </button>

                </div>

                <p id="carousel-counter">1 / 2</p>

            </section>

        </div>

    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/script.js"></script>

</body>

</html>