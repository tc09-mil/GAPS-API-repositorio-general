<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Equipo | Nombre del videojuego</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main class="internal-page">

        <div class="content-container">

            <header class="page-header">

                <h1>Autor</h1>

                <p>
                    Conoce más sobre el autor.
                </p>

            </header>


            <section class="team">

                <h2>Sobre el proyecto</h2>

                <p>

                    Buenas, soy Alan.

                    Cosmo es un proyecto que he desarrollado desde enero de 2026 en clases y tiempo libre. Es mi primer prototipo en Unreal Engine 5, por lo que ha sido un cristo desarrollarlo, especialmente por la curva de aprendizaje. Pero me gustaría llegar a convertirlo en un demo real.

                
                </p>

            </section>


            <section class="newsletter">

                <h2>Recibe información del juego</h2>

                <p>
                    ¡Regístrate para recibir noticias y actualizaciones
                    relacionadas con el desarrollo del videojuego!
                </p>

                <form action="registro.php" method="POST">

                    <div class="form-group">

                        <label for="nombre">Nombre</label>

                        <input
                            type="text"
                            id="nombre"
                            name="nombre"
                            required>

                    </div>


                    <div class="form-group">

                        <label for="correo">Correo electrónico</label>

                        <input
                            type="email"
                            id="correo"
                            name="correo"
                            required>

                    </div>


                    <button type="submit" class="button">
                        Suscribirme
                    </button>

                </form>

            </section>
        </div>
    </main>

    <?php include 'includes/footer.php'; ?>

    <script src="js/script.js"></script>

</body>

</html>