<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Nombre del videojuego</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>

    <link
        href="https://fonts.googleapis.com/css2?family=Spectral:wght@400;500;600;700&display=swap"
        rel="stylesheet">

    <link rel="stylesheet" href="css/style.css">

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    

    <main>

        <section class="hero">

            <img
                src="img/placeholder-title.png"
                alt="Imagen representativa del videojuego"
                class="hero-image">

            <div class="hero-overlay">


                <img
                    src="img/logo.png"
                    alt="Nombre del videojuego"
                    class="game-logo">

                <p class="hero-description">
                    Un sueño abstracto de un joven protagonista. Ayudalo a 
                    sobrevivir y encontrar una salida del mundo que le rechaza.
                </p>

                <a href="juego.php" class="button">
                    Conoce más
                </a>

            </div>

        </section>


        <section class="introduction">

            <h2>Sinopsis</h2>

            <p>
                Este es un juego supervivencia donde el jugador se sumerge dentro del sueño abstracto que vive el personaje principal, un joven llamado Cosmo, mientras sobrevive el mundo que lo rechaza y encuentra una salida de este. 
El personaje fue bendecido con poderes sobrenaturales para ayudarle a navegar diferentes ecosistemas. Este poder, llamado Esencia, forma parte literal de él. Por lo que perder toda su esencia hará que pierda su integridad, haciéndole vulnerable al olvido (o la verdadera muerte).

                
            </p>

        </section>

    </main>

    

    <script src="js/script.js"></script>

</body>

</html>