<?php

include 'includes/db.php';

if (!isset($_GET["id"])) {
    die("Registro no especificado.");
}

$id = $_GET["id"];

$sql = "SELECT nombre, correo
        FROM suscriptores
        WHERE id = ?";

$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $id);
$stmt->execute();

$result = $stmt->get_result();

if ($result->num_rows === 0) {
    die("Registro no encontrado.");
}

$row = $result->fetch_assoc();

$stmt->close();
$conn->close();

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Editar registro | Nombre del videojuego</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main class="internal-page">

        <div class="content-container">

            <header class="page-header">

                <h1>Editar registro</h1>

                <p>
                    Modifica la información del suscriptor.
                </p>

            </header>

            <section>

                <form action="actualizar.php" method="POST">

                    <input
                        type="hidden"
                        name="id"
                        value="<?php echo $id; ?>">

                    <div class="form-group">

                        <label for="nombre">
                            Nombre
                        </label>

                        <input
                            type="text"
                            id="nombre"
                            name="nombre"
                            value="<?php echo htmlspecialchars($row["nombre"]); ?>"
                            required>

                    </div>

                    <div class="form-group">

                        <label for="correo">
                            Correo electrónico
                        </label>

                        <input
                            type="email"
                            id="correo"
                            name="correo"
                            value="<?php echo htmlspecialchars($row["correo"]); ?>"
                            required>

                    </div>

                    <button type="submit" class="button">
                        Guardar cambios
                    </button>

                </form>

            </section>

        </div>

    </main>

    <?php include 'includes/footer.php'; ?>

</body>

</html>