<?php

include 'includes/db.php';

$sql = "SELECT id, nombre, correo, fecha_registro
        FROM suscriptores
        ORDER BY id DESC";

$result = $conn->query($sql);

?>

<!DOCTYPE html>
<html lang="es">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Administración | Nombre del videojuego</title>

    <link rel="stylesheet" href="css/style.css">
</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main class="internal-page">

        <div class="content-container">

            <header class="page-header">

                <h1>Administración</h1>

                <p>
                    Registros de personas interesadas en el videojuego.
                </p>

            </header>

            <section>

                <h2>Suscriptores registrados</h2>

                <?php if ($result->num_rows > 0): ?>

                    <table>

                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nombre</th>
                                <th>Correo</th>
                                <th>Fecha de registro</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>

                        <tbody>

                            <?php while ($row = $result->fetch_assoc()): ?>

                                <tr>

                                    <td>
                                        <?php echo $row["id"]; ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($row["nombre"]); ?>
                                    </td>

                                    <td>
                                        <?php echo htmlspecialchars($row["correo"]); ?>
                                    </td>

                                    <td>
                                        <?php echo $row["fecha_registro"]; ?>
                                    </td>

                                    <td>

                                        <a
                                            href="editar.php?id=<?php echo $row["id"]; ?>"
                                            class="button">
                                            Editar
                                        </a>

                                        <form action="eliminar.php" method="POST">

                                            <input
                                                type="hidden"
                                                name="id"
                                                value="<?php echo $row["id"]; ?>">

                                            <button type="submit" class="button">
                                                Eliminar
                                            </button>

                                        </form>

                                    </td>

                                </tr>

                            <?php endwhile; ?>

                        </tbody>

                    </table>

                <?php else: ?>

                    <p>
                        No hay registros todavía.
                    </p>

                <?php endif; ?>

            </section>

        </div>

    </main>

    <?php include 'includes/footer.php'; ?>

</body>

</html>

<?php

$conn->close();

?>