<?php

include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = $_POST["id"];
    $nombre = $_POST["nombre"];
    $correo = $_POST["correo"];

    $sql = "UPDATE suscriptores
            SET nombre = ?, correo = ?
            WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssi", $nombre, $correo, $id);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit;
    } else {
        echo "Error al actualizar el registro.";
    }

    $stmt->close();
    $conn->close();

} else {
    echo "Acceso no válido.";
}