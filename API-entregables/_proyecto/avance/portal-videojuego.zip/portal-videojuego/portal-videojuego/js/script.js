const carouselImage = document.getElementById("carousel-image");
const previousButton = document.getElementById("previous-button");
const nextButton = document.getElementById("next-button");
const carouselCounter = document.getElementById("carousel-counter");

if (carouselImage && previousButton && nextButton && carouselCounter) {

    const images = [
        "img/mockup-01.jpg",
        "img/mockup-02.jpg"
    ];

    let currentImage = 0;

    function updateCarousel() {
        carouselImage.classList.add("fade");

        setTimeout(function () {
            carouselImage.src = images[currentImage];

            carouselCounter.textContent =
                `${currentImage + 1} / ${images.length}`;

            carouselImage.classList.remove("fade");
        }, 200);
    }

    nextButton.addEventListener("click", function () {
        currentImage++;

        if (currentImage >= images.length) {
            currentImage = 0;
        }

        updateCarousel();
    });

    previousButton.addEventListener("click", function () {
        currentImage--;

        if (currentImage < 0) {
            currentImage = images.length - 1;
        }

        updateCarousel();
    });

}