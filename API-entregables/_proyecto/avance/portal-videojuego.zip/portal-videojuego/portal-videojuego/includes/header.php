<header>
    <nav>
        <a href="index.php">Inicio</a>
        <a href="juego.php">El juego</a>
        <a href="equipo.php">Autor</a>
    </nav>
</header>