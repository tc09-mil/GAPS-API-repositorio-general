<footer>
    <p>&copy; 2026 Alan Lam Páez. Todos los derechos reservados.</p>
</footer>