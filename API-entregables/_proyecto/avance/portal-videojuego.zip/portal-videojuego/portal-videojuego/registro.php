<?php

include 'includes/db.php';

$mensaje = "";
$exito = false;

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $nombre = trim($_POST["nombre"] ?? "");
    $correo = trim($_POST["correo"] ?? "");

    if ($nombre === "" || $correo === "") {

        $mensaje = "Por favor, completa todos los campos.";

    } elseif (!filter_var($correo, FILTER_VALIDATE_EMAIL)) {

        $mensaje = "Introduce un correo electrónico válido.";

    } else {

        $sql = "INSERT INTO suscriptores (nombre, correo)
                VALUES (?, ?)";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ss", $nombre, $correo);

        try {

            if ($stmt->execute()) {

                $mensaje = "Tu registro se realizó correctamente.";
                $exito = true;

            }

        } catch (mysqli_sql_exception $e) {

            if ($e->getCode() === 1062) {

                $mensaje = "Este correo electrónico ya está registrado.";

            } else {

                $mensaje = "No fue posible completar el registro.";
            }
        }
    }

} else {

    $mensaje = "Acceso no válido.";
}

$conn->close();

?>

<!DOCTYPE html>
<html lang="es">

<head>

    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Registro | Nombre del videojuego</title>

    <link rel="stylesheet" href="css/style.css">

</head>

<body>

    <?php include 'includes/header.php'; ?>

    <main class="internal-page">

        <div class="content-container">

            <header class="page-header">

                <h1>
                    <?php echo $exito ? "¡Registro exitoso!" : "Registro"; ?>
                </h1>

                <p>
                    <?php echo htmlspecialchars($mensaje); ?>
                </p>

            </header>

            <section>

                <?php if ($exito): ?>

                    <p>
                        Gracias por tu interés en el videojuego.
                        Te mantendremos informado sobre futuras
                        novedades y actualizaciones.
                    </p>

                    <a href="index.php" class="button">
                        Volver al inicio
                    </a>

                <?php else: ?>

                    <p>
                        No se pudo completar el registro.
                        Regresa al formulario e inténtalo nuevamente.
                    </p>

                    <a href="equipo.php" class="button">
                        Volver al formulario
                    </a>

                <?php endif; ?>

            </section>

        </div>

    </main>

    <?php include 'includes/footer.php'; ?>

</body>

</html>