<?php

include 'includes/db.php';

if ($_SERVER["REQUEST_METHOD"] === "POST") {

    $id = $_POST["id"];

    $sql = "DELETE FROM suscriptores WHERE id = ?";

    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $id);

    if ($stmt->execute()) {
        header("Location: admin.php");
        exit;
    } else {
        echo "Error al eliminar el registro.";
    }

    $stmt->close();
    $conn->close();

} else {
    echo "Acceso no válido.";
}